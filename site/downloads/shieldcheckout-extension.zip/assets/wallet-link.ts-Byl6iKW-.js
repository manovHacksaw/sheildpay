(function(){let t=null;function l(){let e=null;try{e=localStorage.getItem("sc_wallet")}catch{}e&&e!==t&&(t=e,chrome.runtime.sendMessage({type:"wallet-token",token:e}))}l();setInterval(l,3e3);
})()
