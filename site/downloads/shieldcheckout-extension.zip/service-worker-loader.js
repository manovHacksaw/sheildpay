import './assets/service-worker.ts-CoweTuxI.js';
